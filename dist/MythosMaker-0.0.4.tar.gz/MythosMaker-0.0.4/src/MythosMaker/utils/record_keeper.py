
class Record():
    init = "yes"